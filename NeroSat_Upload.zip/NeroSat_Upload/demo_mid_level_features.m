%% extract mid-level features for the dataset
clc
clear
close all

% extract local features
LocalFeatureAll;

% random sampling the clusteringset
GetClusteringSet;

% coding the local features
CodingAll;

