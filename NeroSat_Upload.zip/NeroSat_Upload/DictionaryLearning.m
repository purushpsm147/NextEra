function [ dictionary ] = DictionaryLearning( clusteringSet, codingname, params )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

switch codingname
    case {'bow','spm','plsa','lda'}
        if(~exist('params','var'))
            params.dicSize = 1024;
            params.dr = size(clusteringSet, 2);
        end
        if(~isfield(params,'dicSize'))
            params.dicSize = 1024;
        end
        if(~isfield(params,'dr'))
            params.dr = size(clusteringSet, 2);
        end
        
        dictionary.dic = vl_kmeans(clusteringSet', params.dicSize); 
        dictionary.dic = dictionary.dic';
        
%         options = zeros(1,14);
%         options(1) = 1; % display
%         options(2) = 1;
%         options(3) = 0.1; % precision
%         options(5) = 1; % initialization
%         options(14) = 100; % maximum iterations
%         centers = zeros(params.dicSize, size(clusteringSet,2));
%         dictionary.dic = sp_kmeans(centers, clusteringSet, options);
        
%         [mappedX, mapping] = compute_mapping(clusteringSet, 'PCA', params.dr);
%         dictionary.mappingMatrix = mapping.M;       
        
    case 'llc'
        if(~exist('params','var'))
            params.dicSize = 8192;
            params.dr = size(clusteringSet, 2);
        end
        if(~isfield(params,'dicSize'))
            params.dicSize = 8192;
        end
        if(~isfield(params,'dr'))
            params.dr = size(clusteringSet, 2);
        end
        dictionary.dic = vl_kmeans(clusteringSet', params.dicSize, 'verbose', 'algorithm', 'ann');
        dictionary.dic = dictionary.dic';
%         [mappedX, mapping] = compute_mapping(clusteringSet, 'PCA', params.dr);
%         dictionary.mappingMatrix = mapping.M;
        
    case 'ifk'
        if(~exist('params','var'))
            params.dicSize = 32;
            params.dr = size(clusteringSet, 2);
        end
        if(~isfield(params,'dicSize'))
            params.dicSize = 32;
        end
        if(~isfield(params,'dr'))
            params.dr = size(clusteringSet, 2);
        end
        
%         [mappedX, mapping] = compute_mapping(clusteringSet, 'PCA', params.dr);
        dictionary.dic = traindic(clusteringSet', params.dicSize);
%         dictionary.mappingMatrix = mapping.M;
        
    case 'vlad'
        if(~exist('params','var'))
            params.dicSize = 64;
            params.dr = size(clusteringSet, 2);
        end
        if(~isfield(params,'dicSize'))
            params.dicSize = 64;
        end
        if(~isfield(params,'dr'))
            params.dr = size(clusteringSet, 2);
        end
        
%         [mappedX, mapping] = compute_mapping(clusteringSet, 'PCA', params.dr);
        dictionary.dic = vl_kmeans(clusteringSet', params.dicSize); 
        dictionary.dic = dictionary.dic';
%         dictionary.mappingMatrix = mapping.M;
        
end
end

function dictionary =traindic(data, numClusters)
%%%%%%%%% run fisher encode
% Run KMeans to pre-cluster the data
[initMeans, assignments] = vl_kmeans(data, numClusters, ...
    'Algorithm','Lloyd', ...
    'MaxNumIterations',10);

dimension = size(data,1);
initCovariances = double(zeros(dimension,numClusters));
initPriors = zeros(1,numClusters);
initMeans = double(initMeans);
data = double(data);

% Find the initial means, covariances and priors
for i=1:numClusters
    data_k = data(:,assignments==i);
    initPriors(i) = size(data_k,2) / numClusters;

    if size(data_k,1) == 0 || size(data_k,2) == 0
        initCovariances(:,i) = diag(cov(data'));
    else
        initCovariances(:,i) = diag(cov(data_k'));
    end
end

% Run EM starting from the given parameters
[means,covariances,priors,ll,posteriors] = vl_gmm(data, numClusters, ...
    'initialization','custom', ...
    'InitMeans',initMeans, ...
    'InitCovariances',initCovariances, ...
    'InitPriors',initPriors);

dictionary.means = means;
dictionary.covariances = covariances;
dictionary.priors = priors;

end
