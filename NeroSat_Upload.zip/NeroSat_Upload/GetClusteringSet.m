%% GetClusteringSet

clc;
clear;
close all;

datasetname = '/'; % enter your dataset path here
localfeaturedir = strcat('./temp_data/localfeature/',datasetname);
clusteringsetdir = strcat('./temp_data/clusteringset/',datasetname);
mkdir (clusteringsetdir);

num_img_all = 10000;
fnames = dir(localfeaturedir);
num_files = size(fnames,1);
filenames = cell(num_img_all,1);
num_class = num_files-2;
num_img_per_class = zeros(num_class,1);

%control all the parameters
params.maxImageSize = 600;
params.gridSpacing = 8;
params.patchSize = 16;
params.nbins = 32; %for color histogram
ndata_max = 200000;
params.numTextonImages = 500;
featurename = {'sift','lbp256','ch'};
for lf = 1: length(featurename)
    
    outFName = fullfile(clusteringsetdir, sprintf('clusteringset_%s_%d_%d.mat',...
        featurename{lf}, params.gridSpacing,params.patchSize));
    
    if(exist(outFName,'file')~=0)
        fprintf('%s already exists.\n', outFName);
        continue;
    end
    
    if(params.numTextonImages > num_img_all)
        params.numTextonImages = num_img_all;
    end
    
    R = randperm(num_img_all);
    training_indices = R(1:params.numTextonImages);
    ClusteringSet = [];
    
    for i = 1:num_files
        
        if( (strcmp(fnames(i).name , '.')==1) || (strcmp(fnames(i).name , '..')==1))
            continue;
        end
        subfoldername = fnames(i).name;
        suffixname_localfeature = sprintf('*_%s_%d_%d.mat',...
            featurename{lf}, params.gridSpacing,params.patchSize);
        filename_localfeature = dir(fullfile(strcat(localfeaturedir,subfoldername),suffixname_localfeature));
        if(size(filename_localfeature,1)==0)
            fprintf('You have not extracted the %s local features, please do it first\n', featurename{lf});
            continue;
        end
        num_img_per_class(i-2) = length(filename_localfeature);
        
        for j=1:num_img_per_class(i-2)
            filenames{sum(num_img_per_class(1:i-3))+j,1} = strcat(localfeaturedir,subfoldername,'/',filename_localfeature(j).name);
        end
        
    end
    
    for f = 1:params.numTextonImages
        
        imageFName = filenames{training_indices(f)};
        load(imageFName, 'features');
        ClusteringSet = [ClusteringSet; features.data];
        
    end
    
    fprintf('\nTotal descriptors loaded: %d\n', size(ClusteringSet,1));
    
    ndata = size(ClusteringSet,1);
    if (ndata > ndata_max)
        fprintf('Reducing to %d descriptors\n', ndata_max);
        p = randperm(ndata);
        ClusteringSet = ClusteringSet(p(1:ndata_max),:);
    end
    
    save(outFName,'ClusteringSet')
end